// #.1 실습1
var num01 = 23;
var num02 = 12;
$num_03 = num01 + num02;
document.write("최종합계는" + $num_03 + "입니다.", "</br>");

// #.2 실습2

var num_12 = 12;
var num_5 = 5;
numQuo = num_12 / num_5;
document.write("두 수를 나눈 나머지 값은" + $num_03 + "입니다.", "</br>");

//#.3 실습3
var thisYear = "2024";
var nextYearNum = Number(thisYear) + 1; //2024 + 1
document.write("내년은 " + nextYearNum + "년입니다.", "<br />"); //2024
console.log(nextYearNum);

//#.4 실습4
var women = [2, 4];

console.log(women % 2 == 0 ? "여성입니다." : "남자입니다.");

//#.5 실습5
var $str_bg = "<div class='str_bg'>";
$str_bg += "<img src='./img/kakao_01.jpg'/>";
$str_bg += "<img src='./img/kakao_02.jpg'/>";
$str_bg += "<img src='./img/kakao_03.jpg'/>";
$str_bg += "<img src='./img/kakao_04.jpg'/>";
$str_bg += "</div>";
document.write($str_bg);
